package ipfs

import "github.com/spacemonkeygo/monkit/v3"

var mon = monkit.Package()
