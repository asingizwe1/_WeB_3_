package contract

//go:generate abigen --abi ../../contract/StorjPin.abi --type StorjPin --pkg contract --out pin.go
